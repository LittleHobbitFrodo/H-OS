#ifndef EFI_ELF_H_
#define EFI_ELF_H_ 1

#include "elf32.h"
#include "elf64.h"

#endif
