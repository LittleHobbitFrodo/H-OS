#ifndef __ELF_H__
#define __ELF_H__

#include "elf32.h"
#include "elf64.h"

#endif
