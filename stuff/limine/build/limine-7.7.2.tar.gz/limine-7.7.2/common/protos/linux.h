#ifndef PROTOS__LINUX_H__
#define PROTOS__LINUX_H__

#include <stdnoreturn.h>

noreturn void linux_load(char *config, char *cmdline);

#endif
